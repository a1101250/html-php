<html>
<head>
<meta charset="utf-8">
</head>
<body>
<form action="homeworkcheck.php" method="post">
請輸入帳號:<input input type="text" name="ID"><br/>
請輸入密碼:<input type="password" name="password"><br/>
<input type="submit"> <input type="reset"><br/>
</form>


</body>





</html>