<?php
session_start();

if($_SESSION["login"]=="Principal user"){

}else{
    header("Location:homeworklogin.php");
}
?>
<html>
<head>
<meta charset="utf-8">
</head>

<body>
<?php
echo $_SESSION["login"];
?>

校長網頁<br>
<a href=homeworkteacher.php>老師網頁</a><br>
<a href=homeworklogout.php>logout</a>




</body>    
</html>