<?php
session_start();

if($_SESSION["login"]=="failed"){
    
    
}else{
    header("Location:homeworkerror.php");
}

?>
<?php ob_start(); ?>
<html>
<head>
<meta charset="utf-8">
</head>

<body>
    登入失敗
    網頁將在三秒後跳轉至登入頁面或
    <a href=homeworklogin.php>點選這裡</a>
    <?php
    header("Refresh:3;url=homeworklogin.php")
    
    ?>

</body>    
</html>
<?php ob_flush(); ?>

