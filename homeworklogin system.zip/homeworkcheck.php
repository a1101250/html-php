<?php
session_start();

$StudentID="kevin";
$Studentpassword="2002";

$TeacherID="derrick";
$Teacherpassword="1997";

$PrincipalID="chen";
$Principalpassword="2023";


$ID=$_POST["ID"];
$password=$_POST["password"];

if(($StudentID==$ID) && ($Studentpassword==$password)) {
    $_SESSION["login"]="student user";
    header("Location:homeworkstudent.php");
    
}else if (($TeacherID==$ID) && ($Teacherpassword==$password)) {
    $_SESSION["login"]="Teacher user";
    header("Location:homeworkteacher.php");
    
}else if (($PrincipalID==$ID) && ($Principalpassword==$password)) {
    $_SESSION["login"]="Principal user";
    header("Location:homeworkprincipal.php");
   
} else {
    $_SESSION["login"]="failed";
    header("Location:homeworklogfailed.php");

    session_destroy();
}







?>