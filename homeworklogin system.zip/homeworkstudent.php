<?php
session_start();

if($_SESSION["login"]=="student user" || $_SESSION["login"]="Teacher user") {

}else{
    header("Location:homeworklogin.php");
}
?>

<html>
<head>
<meta charset="utf-8">
</head>

<body>
<?php
echo $_SESSION["login"];
if($_SESSION["login"] == "Principal user") {
    header("Location:homeworklogin.php");
}
?>
學生網頁<br>
<a href=homeworklogout.php>logout</a>


</body>    
</html>