<?php
 session_start();
 session_destroy();
 echo "登出中，三秒後前往登入畫面";
 header("Refresh:3 ; url=homeworklogin.php");
?>